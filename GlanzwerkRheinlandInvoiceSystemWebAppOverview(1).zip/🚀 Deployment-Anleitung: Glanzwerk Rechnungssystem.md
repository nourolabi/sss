# 🚀 Deployment-Anleitung: Glanzwerk Rechnungssystem

## 📋 Übersicht

Diese Anleitung führt Sie durch den kompletten Deployment-Prozess des Glanzwerk Rechnungssystems auf GitHub und Streamlit Cloud.

## 📁 Projektdateien

Das Projekt besteht aus folgenden Dateien:

```
glanzwerk_streamlit/
├── app.py                              # Hauptanwendung
├── pdf_generator_new.py                # PDF-Generator (neues Design)
├── requirements.txt                    # Python-Abhängigkeiten
├── README.md                          # Projektdokumentation
├── Glanzwerk_logo_optimized_under_1MB.png  # Firmenlogo
├── .gitignore                         # Git-Konfiguration
└── glanzwerk.db                       # SQLite-Datenbank (wird automatisch erstellt)
```

## 🔧 Schritt 1: GitHub-Repository erstellen

### 1.1 GitHub-Account vorbereiten
- Melden Sie sich bei [GitHub.com](https://github.com) an
- Erstellen Sie ein neues Repository mit dem Namen `glanzwerk-rechnungssystem`
- Wählen Sie "Public" für kostenlose Streamlit Cloud Nutzung

### 1.2 Repository-Einstellungen
```bash
Repository Name: glanzwerk-rechnungssystem
Description: Intelligentes Rechnungssystem für Glanzwerk Rheinland Autowäscherei
Visibility: Public
Initialize: Ohne README (da bereits vorhanden)
```

### 1.3 Lokales Repository mit GitHub verbinden
```bash
# Im Projektverzeichnis ausführen
git remote add origin https://github.com/[IHR-USERNAME]/glanzwerk-rechnungssystem.git
git branch -M main
git push -u origin main
```

## 🌐 Schritt 2: Streamlit Cloud Deployment

### 2.1 Streamlit Cloud Account erstellen
1. Besuchen Sie [share.streamlit.io](https://share.streamlit.io)
2. Klicken Sie auf "Sign up with GitHub"
3. Autorisieren Sie Streamlit Cloud für Ihren GitHub-Account

### 2.2 App bereitstellen
1. **Neue App erstellen:**
   - Klicken Sie auf "New app"
   - Wählen Sie "From existing repo"

2. **Repository-Details eingeben:**
   ```
   Repository: [IHR-USERNAME]/glanzwerk-rechnungssystem
   Branch: main
   Main file path: app.py
   App URL (optional): glanzwerk-rechnungssystem
   ```

3. **Deployment starten:**
   - Klicken Sie auf "Deploy!"
   - Warten Sie 2-3 Minuten auf die Bereitstellung

### 2.3 App-URL
Nach erfolgreichem Deployment erhalten Sie eine URL wie:
```
https://[app-name]-[random-string].streamlit.app
```

## ⚙️ Schritt 3: Konfiguration und Tests

### 3.1 Erste Tests durchführen
1. Öffnen Sie die bereitgestellte URL
2. Testen Sie die Eingabefelder:
   - Kundenname: "Test Kunde"
   - Fahrzeug: "NR-TK 123"
   - Leistung: Wählen Sie eine Option
3. Generieren Sie eine Testrechnung
4. Laden Sie das PDF herunter und prüfen Sie das Design

### 3.2 Funktionalitäten prüfen
- ✅ Deutsche Benutzeroberfläche
- ✅ Automatische MwSt-Berechnung (19%)
- ✅ Stammkundenrabatt nach 5 Besuchen
- ✅ PDF-Download mit Glanzwerk-Design
- ✅ Responsive Design (Mobile/Desktop)

## 🔄 Schritt 4: Updates und Wartung

### 4.1 Code-Updates
```bash
# Änderungen committen
git add .
git commit -m "Beschreibung der Änderung"
git push origin main
```

**Wichtig:** Streamlit Cloud aktualisiert die App automatisch bei jedem `git push`!

### 4.2 Logs und Debugging
- Streamlit Cloud zeigt Logs in Echtzeit an
- Bei Fehlern: Überprüfen Sie die Konsole in der Streamlit Cloud-Oberfläche

## 📊 Schritt 5: Produktive Nutzung

### 5.1 Benutzerhandbuch für Mitarbeiter
1. **URL aufrufen:** Öffnen Sie die Streamlit-App-URL
2. **Kundendaten eingeben:** Name und Fahrzeugnummer
3. **Leistung auswählen:** Aus dem Dropdown-Menü
4. **Rechnung generieren:** Button klicken
5. **PDF herunterladen:** Grünen Download-Button klicken

### 5.2 Stammkundenrabatt-System
- System verfolgt automatisch Kundenbesuche
- Nach 5 Besuchen: 10% automatischer Rabatt
- Rabatt wird in der Rechnung hervorgehoben

## 🛡️ Schritt 6: Sicherheit und Backup

### 6.1 Datenbank-Backup
- SQLite-Datenbank wird automatisch erstellt
- Für Produktionsumgebung: Regelmäßige Backups empfohlen
- Kundendaten werden lokal in der App gespeichert

### 6.2 Sicherheitshinweise
- Keine sensiblen Daten in den Code einbetten
- Bei Bedarf: Umgebungsvariablen für Konfiguration nutzen
- Streamlit Cloud bietet HTTPS standardmäßig

## 🎯 Schritt 7: Erweiterte Funktionen (Optional)

### 7.1 Custom Domain (Streamlit Pro)
- Für professionelle URL: Upgrade auf Streamlit Pro
- Custom Domain: `rechnungen.glanzwerk-rheinland.de`

### 7.2 Authentifizierung
- Für internen Gebrauch: Streamlit-Authenticator hinzufügen
- Passwort-geschützter Zugang möglich

## 📞 Support und Wartung

### 7.3 Technischer Support
- **Entwickler:** Mazen Design
- **GitHub Issues:** Für Fehlermeldungen und Feature-Requests
- **Streamlit Community:** [discuss.streamlit.io](https://discuss.streamlit.io)

### 7.4 Wartungsplan
- **Monatlich:** Funktionalitätstests durchführen
- **Quartalsweise:** Abhängigkeiten aktualisieren
- **Bei Bedarf:** Neue Features implementieren

## ✅ Checkliste für Go-Live

- [ ] GitHub-Repository erstellt und Code hochgeladen
- [ ] Streamlit Cloud Account eingerichtet
- [ ] App erfolgreich bereitgestellt
- [ ] Alle Funktionen getestet
- [ ] PDF-Design entspricht Glanzwerk-Vorlage
- [ ] URL an Mitarbeiter weitergegeben
- [ ] Benutzerhandbuch erstellt
- [ ] Backup-Strategie definiert

## 🎉 Fertig!

Ihr Glanzwerk Rechnungssystem ist jetzt live und einsatzbereit!

**Live-URL:** [Wird nach Deployment eingefügt]

---

*Entwickelt von Mazen Design für Glanzwerk Rheinland*

